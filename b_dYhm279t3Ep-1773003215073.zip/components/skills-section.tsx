"use client"

import { useRef, useEffect } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)

  const skillCategories = [
    {
      category: "Languages",
      skills: ["JavaScript", "TypeScript", "Python", "Java", "SQL", "PHP", "HTML / CSS"],
    },
    {
      category: "Frameworks & Tools",
      skills: ["React", "Next.js", "Node.js", "Express", "MongoDB", "PostgreSQL", "Tailwind CSS"],
    },
    {
      category: "Concepts",
      skills: ["Data Structures", "Algorithms", "System Design", "Networking", "Database Design"],
    },
  ]

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current || !gridRef.current) return

    const ctx = gsap.context(() => {
      gsap.from(headerRef.current, {
        x: -60,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: headerRef.current,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
      })

      const columns = gridRef.current?.querySelectorAll(":scope > div")
      if (columns) {
        gsap.from(columns, {
          y: 40,
          opacity: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: gridRef.current,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        })
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={sectionRef} id="skills" className="relative py-32 pl-6 md:pl-28 pr-6 md:pr-12">
      {/* Section header */}
      <div ref={headerRef} className="mb-16">
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">02 / Toolkit</span>
        <h2 className="mt-4 font-[var(--font-bebas)] text-5xl md:text-7xl tracking-tight">SKILLS & TECH STACK</h2>
      </div>

      {/* Skills grid */}
      <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {skillCategories.map((category, index) => (
          <div key={index} className="flex flex-col">
            <h3 className="font-[var(--font-bebas)] text-2xl tracking-tight mb-8 text-foreground">
              {category.category}
            </h3>
            <ul className="space-y-3">
              {category.skills.map((skill, skillIndex) => (
                <li
                  key={skillIndex}
                  className="font-mono text-sm text-muted-foreground hover:text-accent transition-colors duration-200 flex items-center gap-3"
                >
                  <span className="w-1.5 h-1.5 bg-accent rounded-full" />
                  {skill}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  )
}
